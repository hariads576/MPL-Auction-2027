MPL AUCTION 2027 — Android phone setup

WHAT THIS ZIP CONTAINS
- index.html: a responsive registration page demo.
- It includes player-only registration, full name, room number, mobile number, image upload previews, ₹400 fee, QR image preview, and payment-proof preview.

IMPORTANT LIMITATION
This is a front-end demo only. It does not send registration data to you, store files centrally, or verify payment. Do not collect real registration fees using this demo until a backend and a secure payment-verification workflow are connected. The QR image chosen in the form is only previewed in that visitor's own browser; it does not become the public QR for every visitor.

OPEN ON ANDROID
1. Download and extract the ZIP file using your phone's Files app.
2. Open index.html in a browser, or use an HTML editor app that has a preview feature.
3. Try the form with sample data. Do not upload sensitive documents while testing.

PUBLISH A PUBLIC DEMO USING GITHUB PAGES (PHONE)
1. Sign in or create an account at https://github.com/
2. Create a new repository named mpl-auction-2027. For a public demo, set it to Public.
3. In the repository, choose Add file > Upload files and upload index.html.
4. Commit the uploaded file.
5. Open repository Settings > Pages.
6. Under Build and deployment, select Deploy from a branch, choose branch main and folder /(root), then Save.
7. Wait for GitHub Pages to publish; the Pages screen will show the live URL. It commonly looks like https://YOUR-USERNAME.github.io/mpl-auction-2027/
8. Open the URL on your phone and test it.

TO MAKE IT PRODUCTION-READY
- Add a backend such as Firebase/Firestore and secure file storage.
- Set up organizer-only access to view registrations.
- Put the actual payment QR in the public site itself (not the visitor's upload field), and confirm payment manually or use a legitimate payment gateway.
- Add privacy notice, data retention policy, spam protection, and clear refund/contact details.
- Never ask users to share UPI PIN, OTP, bank password, or card PIN.
